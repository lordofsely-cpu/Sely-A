package com.sely.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class SelyWakeService : Service() {

    private var speechRecognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var running = false
    private var awaitingCallResponse = false
    private var floatingView: android.view.View? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(42, buildNotification())
        ensureTts()

        if (intent?.action == "ANNOUNCE_CALL") {
            val callerLabel = intent.getStringExtra("caller_label") ?: "someone"
            handleIncomingCall(callerLabel)
            return START_STICKY
        }

        if (!running) {
            running = true
            startWakeLoop()
        }
        return START_STICKY
    }

    private fun ensureTts() {
        if (textToSpeech != null) return
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                textToSpeech?.language = Locale.US
                ttsReady = true
            }
        }
    }

    private fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!ttsReady) {
            onDone?.invoke()
            return
        }
        textToSpeech?.setOnUtteranceProgressListener(object : android.speech.tts.UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { onDone?.invoke() }
            override fun onError(utteranceId: String?) { onDone?.invoke() }
        })
        textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sely_wake_utterance")
    }

    // ---- Incoming call: announce who it is, then listen briefly for "pick up" ----
    private fun handleIncomingCall(callerLabel: String) {
        val wasAlreadyRunning = running
        running = false // pause the normal wake loop while we handle this
        awaitingCallResponse = true

        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = matches?.firstOrNull()?.lowercase() ?: ""
                if (heard.contains("pick up") || heard.contains("answer")) {
                    acceptCall()
                }
                finishCallHandling(wasAlreadyRunning)
            }
            override fun onError(error: Int) {
                finishCallHandling(wasAlreadyRunning)
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })

        speak("Incoming call from $callerLabel. Say pick up to answer.") {
            val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            }
            try {
                speechRecognizer?.startListening(recognizerIntent)
            } catch (e: Exception) {
                finishCallHandling(wasAlreadyRunning)
            }
            // Safety timeout in case the call is picked up manually or nothing is heard
            android.os.Handler(mainLooper).postDelayed({
                if (awaitingCallResponse) finishCallHandling(wasAlreadyRunning)
            }, 8000)
        }
    }

    private fun acceptCall() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED) {
            speak("I need call-answering permission first.")
            return
        }
        try {
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
            telecomManager.acceptRingingCall()

            val prefs = getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)
            val busyMode = prefs.getBoolean("busy_mode", false)
            if (busyMode) {
                val message = prefs.getString("busy_call_message", DEFAULT_BUSY_CALL_MESSAGE) ?: DEFAULT_BUSY_CALL_MESSAGE
                // Give the call a moment to actually connect before speaking into it
                android.os.Handler(mainLooper).postDelayed({ speakIntoCall(message) }, 1200)
            }
        } catch (e: Exception) {
            speak("I couldn't answer the call.")
        }
    }

    // Best-effort: routes speech to the voice-call audio stream so the caller can hear it.
    // This is NOT guaranteed to work on every device/carrier — Android restricts third-party
    // apps from injecting audio into an active call on many phones for privacy reasons.
    private fun speakIntoCall(message: String) {
        try {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
            audioManager.mode = android.media.AudioManager.MODE_IN_COMMUNICATION

            val params = Bundle()
            params.putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_VOICE_CALL)

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val attributes = android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                textToSpeech?.setAudioAttributes(attributes)
            }

            textToSpeech?.speak(message, TextToSpeech.QUEUE_FLUSH, params, "sely_call_message")
        } catch (e: Exception) {
            // If this fails, the call is still answered — it just stays silent from Sely's side
        }
    }

    companion object {
        const val DEFAULT_BUSY_CALL_MESSAGE = "This is Kingsley's personal assistant speaking with you. The person you are trying to reach is very busy. Please call back later."
    }

    private fun finishCallHandling(resumeWakeLoop: Boolean) {
        if (!awaitingCallResponse) return
        awaitingCallResponse = false
        if (resumeWakeLoop) {
            running = true
            relisten()
        } else {
            // This service instance was only started for this one call — stop it now
            stopSelf()
        }
    }

    private fun buildNotification(): android.app.Notification {
        val channelId = "sely_wake_service"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(channelId, "Sely Wake Word", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Sely is listening")
            .setContentText("Say \"Hey Sely\" anytime")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
    }

    private fun updateNotificationWithLastHeard(text: String) {
        val channelId = "sely_wake_service"
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Sely is listening")
            .setContentText(if (text.isEmpty()) "Last heard: (nothing captured)" else "Last heard: \"$text\"")
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).notify(42, notification)
    }

    private fun startWakeLoop() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val heard = matches?.firstOrNull()?.lowercase() ?: ""
                updateNotificationWithLastHeard(heard)
                if (heard.contains("hey sely") || heard.contains("hey sally") || heard.contains("hey selly")) {
                    onWakeWordDetected()
                    // Don't relisten immediately — the next step needs the mic for a bit.
                    // Without this pause, both recognizers fight over the mic and both fail.
                    android.os.Handler(mainLooper).postDelayed({ relisten() }, 15000)
                } else {
                    relisten()
                }
            }

            override fun onError(error: Int) {
                updateNotificationWithLastHeard("(recognizer error $error, retrying)")
                // A short pause before retrying gives the recognizer time to actually reset —
                // restarting instantly is what causes the rapid on/off flicker.
                android.os.Handler(mainLooper).postDelayed({ relisten() }, 800)
            }

            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })
        relisten()
    }

    private fun relisten() {
        if (!running) return
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3000)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 2500)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 15000)
        }
        try {
            speechRecognizer?.startListening(intent)
        } catch (e: Exception) {
            // Mic busy or unavailable — try again shortly
            android.os.Handler(mainLooper).postDelayed({ relisten() }, 1500)
        }
    }

    // ---- Called the moment "Hey Sely" is heard: shows the floating icon over whatever app
    // you're in, greets you, then listens for your actual command RIGHT THERE (icon stays up)
    // before opening the app — see the fuller version further below that replaces this flow ----

    private fun showFloatingIcon() {
        if (floatingView != null) return
        try {
            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val icon = ImageView(this)
            icon.setImageResource(R.drawable.sely_avatar)
            icon.background = ContextCompat.getDrawable(this, R.drawable.avatar_ring)
            val sizePx = (72 * resources.displayMetrics.density).toInt()
            val padding = (4 * resources.displayMetrics.density).toInt()
            icon.setPadding(padding, padding, padding, padding)
            icon.clipToOutline = true

            val overlayType = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            val params = WindowManager.LayoutParams(
                sizePx, sizePx, overlayType,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            )
            params.gravity = Gravity.TOP or Gravity.END
            params.x = 24
            params.y = 200

            windowManager.addView(icon, params)
            floatingView = icon

            // A little pop-in animation so it doesn't just harshly appear
            icon.alpha = 0f
            icon.scaleX = 0.5f
            icon.scaleY = 0.5f
            icon.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(250).start()
        } catch (e: Exception) {
            // If the overlay fails for any device-specific reason, just skip it silently —
            // the app will still open normally to handle the command
        }
    }

    private fun removeFloatingIcon() {
        val view = floatingView ?: return
        try {
            val windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            windowManager.removeView(view)
        } catch (e: Exception) {
            // Already removed or window gone — nothing to do
        }
        floatingView = null
    }

    // ---- Called the moment "Hey Sely" is heard: shows the floating icon over whatever app
    // you're in, greets you, then listens for your actual command RIGHT THERE (icon stays up)
    // before opening the app — this is what was covering the icon before it could be seen ----
    private fun onWakeWordDetected() {
        val overlayGranted = Settings.canDrawOverlays(this)
        if (overlayGranted) showFloatingIcon()

        speak("Hello boss, what do you need?") {
            listenForCommandThenOpenApp(overlayGranted)
        }
    }

    private fun listenForCommandThenOpenApp(overlayWasShown: Boolean) {
        if (speechRecognizer == null) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        }
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = matches?.firstOrNull()?.lowercase() ?: ""
                if (overlayWasShown) removeFloatingIcon()
                launchMainActivityWithCommand(command)
            }
            override fun onError(error: Int) {
                if (overlayWasShown) removeFloatingIcon()
                // Nothing captured — still open the app so the person can try typing/tapping instead
                launchMainActivityWithCommand("")
            }
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })

        val recognizerIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")
        }
        try {
            speechRecognizer?.startListening(recognizerIntent)
        } catch (e: Exception) {
            if (overlayWasShown) removeFloatingIcon()
            launchMainActivityWithCommand("")
        }
    }

    private fun launchMainActivityWithCommand(command: String) {
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (command.isNotEmpty()) {
                putExtra("pending_command", command)
            } else {
                putExtra("auto_listen", true)
            }
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        running = false
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        removeFloatingIcon()
        super.onDestroy()
    }
}
