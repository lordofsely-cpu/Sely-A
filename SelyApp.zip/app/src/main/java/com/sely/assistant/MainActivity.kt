package com.sely.assistant

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.app.AlarmManager
import android.app.PendingIntent
import android.provider.ContactsContract
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : AppCompatActivity() {

    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var statusText: TextView
    private lateinit var textToSpeech: TextToSpeech
    private lateinit var prefs: SharedPreferences
    private lateinit var orbButton: ImageButton
    private lateinit var chatLog: LinearLayout
    private lateinit var scrollContainer: ScrollView
    private var pulseAnimator: ObjectAnimator? = null
    private var flashlightOn = false
    private var ttsReady = false
    private val conversationHistory = mutableListOf<Pair<String, String>>() // question to answer, this session only

    private val requiredPermissions: Array<String>
        get() {
            val base = mutableListOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS,
                Manifest.permission.READ_CONTACTS,
                Manifest.permission.CAMERA
            )
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                base.add(Manifest.permission.POST_NOTIFICATIONS)
            }
            base.add(Manifest.permission.READ_PHONE_STATE)
            base.add(Manifest.permission.READ_CALL_LOG)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                base.add(Manifest.permission.ANSWER_PHONE_CALLS)
            }
            return base.toTypedArray()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        statusText = findViewById(R.id.statusText)
        orbButton = findViewById(R.id.orbButton)
        chatLog = findViewById(R.id.chatLog)
        scrollContainer = findViewById(R.id.scrollContainer)
        val settingsButton = findViewById<TextView>(R.id.settingsButton)
        val chatInput = findViewById<EditText>(R.id.chatInput)
        val chatSendButton = findViewById<Button>(R.id.chatSendButton)

        val sendTypedCommand = {
            val typed = chatInput.text.toString().trim()
            if (typed.isNotEmpty()) {
                addChatBubble(typed, isUser = true)
                chatInput.setText("")
                handleCommand(typed.lowercase())
            }
        }
        chatSendButton.setOnClickListener { sendTypedCommand() }
        chatInput.setOnEditorActionListener { _, actionId, event ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_DONE ||
                (event?.keyCode == android.view.KeyEvent.KEYCODE_ENTER && event.action == android.view.KeyEvent.ACTION_DOWN)) {
                sendTypedCommand()
                true
            } else false
        }

        prefs = getSharedPreferences("sely_prefs", Context.MODE_PRIVATE)

        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val savedLang = prefs.getString("sely_language", "en-US") ?: "en-US"
                textToSpeech.language = java.util.Locale.forLanguageTag(savedLang)
                ttsReady = true
                textToSpeech.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) {
                        runOnUiThread { stopPulse() }
                    }
                    override fun onError(utteranceId: String?) {
                        runOnUiThread { stopPulse() }
                    }
                })
                if (pendingGreeting) {
                    pendingGreeting = false
                    runOnUiThread { greetThenListen() }
                }
            }
        }

        settingsButton.setOnClickListener { showApiKeyDialog() }

        requestNeededPermissions()

        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                statusText.text = "Listening..."
                startPulse()
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val command = matches?.firstOrNull()?.lowercase() ?: ""
                statusText.text = if (command.isNotEmpty()) "Heard: \"$command\"" else "Didn't catch that"
                if (command.isEmpty()) stopPulse()
                if (command.isNotEmpty()) {
                    addChatBubble(command, isUser = true)
                    handleCommand(command)
                }
            }

            override fun onError(error: Int) {
                statusText.text = "Didn't catch that — tap to try again"
                stopPulse()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onPartialResults(partialResults: Bundle?) {}
        })

        orbButton.setOnClickListener { startListening() }

        if (intent.getBooleanExtra("auto_listen", false)) {
            if (ttsReady) greetThenListen() else pendingGreeting = true
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.getBooleanExtra("auto_listen", false)) {
            if (ttsReady) greetThenListen() else pendingGreeting = true
        }
    }

    private var pendingGreeting = false

    private val wakeGreetings = listOf(
        "Hello boss, what do you need?",
        "Yes boss, I'm listening.",
        "Hello boss, go ahead."
    )

    private fun greetThenListen() {
        speak(wakeGreetings.random())
        orbButton.postDelayed({ startListening() }, 1800)
    }

    private fun startPulse() {
        pulseAnimator?.cancel()
        pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
            orbButton,
            PropertyValuesHolder.ofFloat("scaleX", 1f, 1.1f),
            PropertyValuesHolder.ofFloat("scaleY", 1f, 1.1f)
        ).apply {
            duration = 550
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun stopPulse() {
        pulseAnimator?.cancel()
        orbButton.scaleX = 1f
        orbButton.scaleY = 1f
    }

    private fun requestNeededPermissions() {
        val missing = requiredPermissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
        }
    }

    private fun startListening() {
        val languageCode = prefs.getString("sely_language", "en-US") ?: "en-US"
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageCode)
        }
        try {
            speechRecognizer.startListening(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Microphone not available", Toast.LENGTH_SHORT).show()
        }
    }

    // ---- Command router: more specific/startsWith commands are checked first to avoid
    // generic keyword collisions (e.g. "remind me to call mom" shouldn't trigger the call handler) ----
    private fun handleCommand(command: String) {
        when {
            command.startsWith("remember that ") -> rememberFact(command.removePrefix("remember that ").trim())
            command.startsWith("remember ") -> rememberFact(command.removePrefix("remember ").trim())
            command.contains("what do you remember") || command.contains("what have i told you") -> recallFacts()
            command.contains("forget everything") -> forgetAll()
            command.startsWith("remind me to ") -> handleReminderCommand(command)
            command.contains("what are my reminders") || command.contains("what's on my schedule") -> listReminders()
            command.startsWith("delete the reminder") || command.startsWith("delete reminder") || command.startsWith("cancel the reminder") -> deleteReminder(command)
            command.startsWith("reply saying ") -> prepareReply(command.removePrefix("reply saying ").trim())
            command == "confirm" || command == "yes send it" || command == "send it" -> confirmReply()
            command.contains("what's my last message") || command.contains("read my last message") || command.contains("do i have any messages") -> readLastMessage()
            command.contains("enable notification access") -> openNotificationAccessSettings()
            command.contains("what time is it") || command.contains("what's the time") -> tellTime()
            command.contains("battery") -> tellBattery()
            command.contains("volume up") || command.contains("turn up the volume") -> adjustVolume(true)
            command.contains("volume down") || command.contains("turn down the volume") -> adjustVolume(false)
            command.contains("turn on wifi") || command.contains("turn off wifi") -> openWifiSettings()
            command.contains("turn on bluetooth") || command.contains("turn off bluetooth") -> openBluetoothSettings()
            command.contains("read my messages") || command.contains("check my inbox") || command.contains("my inbox") -> showInbox()
            command.startsWith("play ") -> playMusic(command.removePrefix("play ").trim())
            command == "pause music" || command == "pause" -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PAUSE)
            command == "resume music" || command == "resume" || command == "unpause" -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PLAY)
            command.contains("next song") || command.contains("skip") -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_NEXT)
            command.contains("previous song") || command.contains("last song") -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            command == "stop music" || command == "stop" -> sendMediaKey(android.view.KeyEvent.KEYCODE_MEDIA_STOP)
            command.contains("answer the call") || command == "answer" || command == "pick up" || command.contains("pick up the call") -> answerCall()
            command.contains("turn on busy mode") -> setBusyMode(true)
            command.contains("turn off busy mode") -> setBusyMode(false)
            command.startsWith("set busy message to ") -> setBusyMessage(command.removePrefix("set busy message to ").trim())
            command.startsWith("set busy call message to ") -> setBusyCallMessage(command.removePrefix("set busy call message to ").trim())
            command.contains("whatsapp") -> handleWhatsAppCommand(command)
            command.contains("open camera") -> {
                speak("Opening the camera now.")
                openCamera()
            }
            command.contains("open gmail") || command.contains("open email") -> {
                speak("Opening your email.")
                openApp("com.google.android.gm")
            }
            command.contains("turn on flashlight") || command.contains("flashlight on") -> {
                setFlashlight(true)
                speak("Flashlight's on.")
            }
            command.contains("turn off flashlight") || command.contains("flashlight off") -> {
                setFlashlight(false)
                speak("Flashlight's off.")
            }
            command.startsWith("open ") -> openAppByName(command.removePrefix("open ").trim())
            command.startsWith("call ") -> {
                val target = command.substringAfter("call ").trim()
                val number = resolveTarget(target)
                if (number == null) {
                    speak("I couldn't find a contact called $target.")
                } else {
                    speak("Calling $target now.")
                    callContact(number)
                }
            }
            command.startsWith("text ") -> {
                handleTextCommand(command)
            }
            else -> askGemini(command)
        }
    }

    private fun deleteReminder(command: String) {
        val reminders = loadReminderObjects()
        if (reminders.length() == 0) {
            speak("You don't have any reminders set.")
            return
        }
        var matchIndex = -1
        var matchTask = ""
        var matchRequestCode = 0
        for (i in 0 until reminders.length()) {
            val obj = reminders.getJSONObject(i)
            val task = obj.getString("task").lowercase()
            if (command.contains(task)) {
                matchIndex = i
                matchTask = obj.getString("task")
                matchRequestCode = obj.getInt("requestCode")
                break
            }
        }
        if (matchIndex == -1) {
            speak("I couldn't find a reminder matching that. Say \"what are my reminders\" to hear them.")
            return
        }

        // Cancel the actual scheduled alarm using the same request code it was created with
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val cancelIntent = Intent(this, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            this, matchRequestCode, cancelIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)

        val updated = JSONArray()
        for (i in 0 until reminders.length()) {
            if (i != matchIndex) updated.put(reminders.getJSONObject(i))
        }
        saveReminderObjects(updated)

        statusText.text = "Deleted: $matchTask"
        speak("Deleted the reminder to $matchTask, and cancelled the alarm.")
    }

    private fun tellTime() {
        val now = android.text.format.DateFormat.format("h:mm a", java.util.Calendar.getInstance()).toString()
        speak("It's $now.")
    }

    private fun tellBattery() {
        val batteryManager = getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
        val level = batteryManager.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)
        speak("Your battery is at $level percent.")
    }

    private fun adjustVolume(up: Boolean) {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        audioManager.adjustStreamVolume(
            android.media.AudioManager.STREAM_MUSIC,
            if (up) android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER,
            android.media.AudioManager.FLAG_SHOW_UI
        )
        speak(if (up) "Turning it up." else "Turning it down.")
    }

    // Android blocks apps from silently toggling WiFi/Bluetooth since Android 10 — the safe,
    // policy-compliant way is to open the relevant settings panel for the user to flip it themselves.
    private fun openWifiSettings() {
        speak("Opening WiFi settings for you.")
        startActivity(Intent(android.provider.Settings.Panel.ACTION_WIFI))
    }

    private fun openBluetoothSettings() {
        speak("Opening Bluetooth settings for you.")
        startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))
    }

    private fun showInbox() {
        val raw = prefs.getString("recent_messages", "[]") ?: "[]"
        val arr = JSONArray(raw)
        if (arr.length() == 0) {
            speak("Your inbox is empty, or notification access isn't turned on yet.")
            return
        }
        val lines = StringBuilder()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            lines.append("${obj.getString("sender")}: ${obj.getString("text")}\n")
        }
        AlertDialog.Builder(this)
            .setTitle("Recent messages")
            .setMessage(lines.toString().trim())
            .setPositiveButton("Close", null)
            .show()
    }

    // ---- Memory: simple local storage of facts the user tells Sely ----
    private fun loadMemories(): MutableList<String> {
        val raw = prefs.getString("sely_memories", "[]") ?: "[]"
        val arr = JSONArray(raw)
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) list.add(arr.getString(i))
        return list
    }

    private fun saveMemories(list: List<String>) {
        val arr = JSONArray()
        list.forEach { arr.put(it) }
        prefs.edit().putString("sely_memories", arr.toString()).apply()
    }

    private fun rememberFact(fact: String) {
        if (fact.isEmpty()) {
            speak("What should I remember?")
            return
        }
        val memories = loadMemories()
        memories.add(fact)
        saveMemories(memories)
        statusText.text = "Remembered: $fact"
        speak("Got it, I'll remember that $fact.")
    }

    private fun recallFacts() {
        val memories = loadMemories()
        if (memories.isEmpty()) {
            statusText.text = "You haven't told me anything to remember yet"
            speak("You haven't told me anything to remember yet.")
        } else {
            val summary = memories.joinToString(". ")
            statusText.text = summary
            speak("Here's what I remember. $summary")
        }
    }

    private fun forgetAll() {
        saveMemories(emptyList())
        statusText.text = "Cleared everything I remembered"
        speak("Okay, I've forgotten everything you told me.")
    }

    // ---- Reminders: parses "remind me to X at H(:MM)(am/pm)" and schedules a real system alarm ----
    private fun handleReminderCommand(command: String) {
        val rest = command.removePrefix("remind me to ").trim()
        val atIndex = rest.lastIndexOf(" at ")
        if (atIndex == -1) {
            speak("Say it like: remind me to call mom at 5 PM.")
            return
        }
        val task = rest.substring(0, atIndex).trim()
        val timePart = rest.substring(atIndex + 4).trim()
        val cal = parseTimeToCalendar(timePart)
        if (cal == null) {
            speak("I couldn't understand that time. Try something like 5 PM or 5:30.")
            return
        }

        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
            speak("I need permission to schedule exact alarms first. Opening settings — please turn it on, then try again.")
            startActivity(Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM))
            return
        }

        val requestCode = (task + timePart).hashCode()
        val intent = Intent(this, ReminderReceiver::class.java).putExtra("reminder_text", task)
        val pendingIntent = PendingIntent.getBroadcast(
            this, requestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pendingIntent)

        val display = android.text.format.DateFormat.format("h:mm a, EEE", cal).toString()
        val reminders = loadReminderObjects()
        reminders.put(JSONObject().apply {
            put("task", task)
            put("display", display)
            put("requestCode", requestCode)
        })
        saveReminderObjects(reminders)

        statusText.text = "Reminder set: $task at $display"
        speak("Okay, I'll remind you to $task at $display.")
    }

    private fun parseTimeToCalendar(timePart: String): java.util.Calendar? {
        val regex = Regex("""(\d{1,2})(?::(\d{2}))?\s*(am|pm)?""", RegexOption.IGNORE_CASE)
        val match = regex.find(timePart) ?: return null
        var hour = match.groupValues[1].toIntOrNull() ?: return null
        val minute = match.groupValues[2].toIntOrNull() ?: 0
        val meridiem = match.groupValues[3].lowercase()

        if (meridiem == "pm" && hour < 12) hour += 12
        if (meridiem == "am" && hour == 12) hour = 0

        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, hour)
        cal.set(java.util.Calendar.MINUTE, minute)
        cal.set(java.util.Calendar.SECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) {
            cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        }
        return cal
    }

    private fun loadReminderObjects(): JSONArray {
        val raw = prefs.getString("sely_reminder_list", "[]") ?: "[]"
        return JSONArray(raw)
    }

    private fun saveReminderObjects(arr: JSONArray) {
        prefs.edit().putString("sely_reminder_list", arr.toString()).apply()
    }

    private fun listReminders() {
        val reminders = loadReminderObjects()
        if (reminders.length() == 0) {
            speak("You have no reminders set.")
        } else {
            val parts = mutableListOf<String>()
            for (i in 0 until reminders.length()) {
                val obj = reminders.getJSONObject(i)
                parts.add("${obj.getString("task")} at ${obj.getString("display")}")
            }
            val summary = parts.joinToString(". ")
            statusText.text = summary
            speak("Here's what's coming up. $summary")
        }
    }

    // ---- Incoming messages: read via NotificationListener, reply requires spoken confirmation ----
    private var pendingReplyText: String? = null

    private fun readLastMessage() {
        val sender = prefs.getString("last_message_sender", null)
        val text = prefs.getString("last_message_text", null)
        if (sender == null || text == null) {
            speak("You have no recent messages, or notification access isn't turned on yet. Say enable notification access to fix that.")
        } else {
            statusText.text = "$sender: $text"
            speak("$sender says: $text")
        }
    }

    private fun prepareReply(messageText: String) {
        if (SelyNotificationListener.lastReplyAction == null) {
            speak("I don't have a live message to reply to right now. Open the chat once, then try again.")
            return
        }
        pendingReplyText = messageText
        val sender = SelyNotificationListener.lastSender ?: "them"
        statusText.text = "Ready to send to $sender: \"$messageText\". Say confirm to send."
        speak("Ready to send to $sender: $messageText. Say confirm to send it.")
    }

    private fun confirmReply() {
        val text = pendingReplyText
        val action = SelyNotificationListener.lastReplyAction
        if (text == null || action == null) {
            speak("There's nothing waiting to be sent.")
            return
        }
        try {
            val remoteInput = action.remoteInputs!!.first()
            val intent = android.content.Intent()
            val bundle = Bundle()
            bundle.putCharSequence(remoteInput.resultKey, text)
            android.app.RemoteInput.addResultsToIntent(action.remoteInputs, intent, bundle)
            action.actionIntent.send(this, 0, intent)
            speak("Sent.")
        } catch (e: Exception) {
            speak("Sorry, I couldn't send that reply.")
        }
        pendingReplyText = null
    }

    private fun openNotificationAccessSettings() {
        speak("Opening notification access settings. Please turn on access for Sely.")
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
    }

    private fun showApiKeyDialog() {
        val input = EditText(this)
        input.hint = "Paste your free Gemini API key"
        input.setText(prefs.getString("gemini_key", ""))
        AlertDialog.Builder(this)
            .setTitle("Gemini API key")
            .setMessage("Get a free key at aistudio.google.com/apikey — no credit card needed.")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                prefs.edit().putString("gemini_key", input.text.toString().trim()).apply()
                statusText.text = "Key saved"
            }
            .setNeutralButton(if (isWakeServiceRunning) "Turn off always-listen" else "Turn on always-listen (\"Hey Sely\")") { _, _ ->
                toggleWakeService()
            }
            .setNegativeButton("Language") { _, _ -> showLanguageDialog() }
            .show()

        if (!android.provider.Settings.canDrawOverlays(this)) {
            AlertDialog.Builder(this)
                .setTitle("One more permission")
                .setMessage("For the floating Sely icon to appear when you say \"Hey Sely\" in other apps, allow \"display over other apps\" on the next screen.")
                .setPositiveButton("Open settings") { _, _ ->
                    val intent = Intent(
                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                    startActivity(intent)
                }
                .setNegativeButton("Skip", null)
                .show()
        }
    }

    private val supportedLanguages = linkedMapOf(
        "English (US)" to "en-US",
        "English (UK)" to "en-GB",
        "Spanish" to "es-ES",
        "French" to "fr-FR",
        "Portuguese" to "pt-PT",
        "Hausa" to "ha-NG",
        "Yoruba" to "yo-NG",
        "Igbo" to "ig-NG",
        "Arabic" to "ar-SA",
        "Hindi" to "hi-IN"
    )

    private fun showLanguageDialog() {
        val names = supportedLanguages.keys.toTypedArray()
        val codes = supportedLanguages.values.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Choose a language")
            .setItems(names) { _, index ->
                val code = codes[index]
                prefs.edit().putString("sely_language", code).apply()
                textToSpeech.language = java.util.Locale.forLanguageTag(code)
                statusText.text = "Language set to ${names[index]}"
                speak("Language set.")
            }
            .show()
    }

    private var isWakeServiceRunning = false

    private fun toggleWakeService() {
        val serviceIntent = Intent(this, SelyWakeService::class.java)
        if (isWakeServiceRunning) {
            stopService(serviceIntent)
            isWakeServiceRunning = false
            prefs.edit().putBoolean("always_listen_enabled", false).apply()
            statusText.text = "Always-listen turned off"
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            isWakeServiceRunning = true
            prefs.edit().putBoolean("always_listen_enabled", true).apply()
            statusText.text = "Always-listen on — say \"Hey Sely\" anytime"
        }
    }

    private fun memoryContextBlock(): String {
        val memories = loadMemories()
        if (memories.isEmpty()) return ""
        return " Here are things the user has told you to remember, use them if relevant: " +
            memories.joinToString("; ") + "."
    }

    private fun conversationContextBlock(): String {
        if (conversationHistory.isEmpty()) return ""
        val recent = conversationHistory.joinToString(" ") { (q, a) -> "User asked: $q. You answered: $a." }
        return " Recent conversation this session, for context on follow-up questions: $recent"
    }

    private fun askGemini(question: String) {
        val key = prefs.getString("gemini_key", "") ?: ""
        if (key.isEmpty()) {
            statusText.text = "Add your Gemini key in Settings first"
            speak("Please add your Gemini key in settings first.")
            return
        }
        statusText.text = "Thinking..."
        Thread {
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-flash-latest:generateContent?key=$key")
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "POST"
                connection.setRequestProperty("Content-Type", "application/json")
                connection.doOutput = true

                val systemPrompt = "You are Sely, a personal voice assistant on the user's phone. " +
                    "If asked who created you, say you were created by a smart developer called Kingsley. " +
                    "Answer briefly and conversationally, in 1-3 sentences, since your answer will be spoken aloud." +
                    memoryContextBlock() + conversationContextBlock()

                val body = JSONObject().apply {
                    put("systemInstruction", JSONObject().apply {
                        put("parts", org.json.JSONArray().put(JSONObject().put("text", systemPrompt)))
                    })
                    put("contents", org.json.JSONArray().put(JSONObject().apply {
                        put("role", "user")
                        put("parts", org.json.JSONArray().put(JSONObject().put("text", question)))
                    }))
                }

                connection.outputStream.use { it.write(body.toString().toByteArray()) }

                val responseCode = connection.responseCode
                val stream = if (responseCode in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }
                val json = JSONObject(responseText)

                val answer = if (json.has("candidates")) {
                    json.getJSONArray("candidates")
                        .getJSONObject(0)
                        .getJSONObject("content")
                        .getJSONArray("parts")
                        .getJSONObject(0)
                        .getString("text")
                } else {
                    "Sorry, I couldn't get an answer just now."
                }

                runOnUiThread {
                    statusText.text = answer
                    speak(answer)
                    conversationHistory.add(question to answer)
                    if (conversationHistory.size > 6) conversationHistory.removeAt(0)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    statusText.text = "Couldn't reach Gemini — check your connection"
                }
            }
        }.start()
    }

    private fun speak(text: String) {
        addChatBubble(text, isUser = false)
        if (ttsReady) {
            textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "sely_utterance")
        } else {
            stopPulse()
        }
    }

    private fun addChatBubble(text: String, isUser: Boolean) {
        val bubble = TextView(this)
        bubble.text = text
        bubble.textSize = 14f
        bubble.setPadding(28, 20, 28, 20)
        bubble.setTextColor(resources.getColor(if (isUser) R.color.text else R.color.accent, theme))
        val params = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        params.gravity = if (isUser) android.view.Gravity.END else android.view.Gravity.START
        params.topMargin = 12
        bubble.layoutParams = params
        bubble.setBackgroundResource(R.drawable.orb_background)
        chatLog.addView(bubble)
        scrollContainer.post { scrollContainer.fullScroll(android.view.View.FOCUS_DOWN) }
    }

    private fun handleWhatsAppCommand(command: String) {
        // Expected pattern: "whatsapp <name or number> <message>" — e.g. "whatsapp mom I'm on my way"
        val rest = command.substringAfter("whatsapp").trim()
        val parts = rest.split(" ", limit = 2)

        if (parts.isEmpty() || parts[0].isEmpty() || parts.size < 2) {
            speak("Opening WhatsApp for you.")
            openApp("com.whatsapp")
            return
        }

        val number = resolveTarget(parts[0])
        if (number == null) {
            speak("I couldn't find a contact called ${parts[0]}.")
            return
        }
        val message = parts[1]
        speak("Opening WhatsApp with your message. Tap send when you're ready.")
        try {
            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$number&text=${Uri.encode(message)}")
            val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.whatsapp") }
            startActivity(intent)
        } catch (e: Exception) {
            statusText.text = "Couldn't open that WhatsApp chat"
            speak("Sorry, I couldn't open that chat.")
        }
    }

    // ---- Media controls: sends a standard media button event to whichever app is currently playing ----
    private fun sendMediaKey(keyCode: Int) {
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val eventTime = android.os.SystemClock.uptimeMillis()

        val downEvent = android.view.KeyEvent(eventTime, eventTime, android.view.KeyEvent.ACTION_DOWN, keyCode, 0)
        val upEvent = android.view.KeyEvent(eventTime, eventTime, android.view.KeyEvent.ACTION_UP, keyCode, 0)
        audioManager.dispatchMediaKeyEvent(downEvent)
        audioManager.dispatchMediaKeyEvent(upEvent)

        val label = when (keyCode) {
            android.view.KeyEvent.KEYCODE_MEDIA_PAUSE -> "Paused."
            android.view.KeyEvent.KEYCODE_MEDIA_PLAY -> "Resuming."
            android.view.KeyEvent.KEYCODE_MEDIA_NEXT -> "Skipping."
            android.view.KeyEvent.KEYCODE_MEDIA_PREVIOUS -> "Going back."
            android.view.KeyEvent.KEYCODE_MEDIA_STOP -> "Stopped."
            else -> "Done."
        }
        speak(label)
    }

    // ---- Music: uses Android's standard "play from search" intent — works with whatever music app you have ----
    private fun playMusic(songQuery: String) {
        if (songQuery.isEmpty()) {
            speak("What should I play?")
            return
        }
        speak("Playing $songQuery.")
        val intent = Intent(android.provider.MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            putExtra(android.app.SearchManager.QUERY, songQuery)
            putExtra("android.intent.extra.focus", "vnd.android.cursor.item/*")
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            statusText.text = "No music app found that supports this"
            speak("I couldn't find a music app to play that with.")
        }
    }

    // ---- Answer an incoming call — only works if Sely is actively listening at that moment ----
    private fun answerCall() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ANSWER_PHONE_CALLS)
            != PackageManager.PERMISSION_GRANTED) {
            speak("I need call-answering permission first. Please grant it in the app permissions.")
            return
        }
        try {
            val telecomManager = getSystemService(Context.TELECOM_SERVICE) as android.telecom.TelecomManager
            telecomManager.acceptRingingCall()
            speak("Answered.")
        } catch (e: Exception) {
            speak("I couldn't answer the call.")
        }
    }

    // ---- Busy mode: when on, incoming messages get an automatic canned reply, no confirmation step ----
    private fun setBusyMode(on: Boolean) {
        prefs.edit().putBoolean("busy_mode", on).apply()
        if (on) {
            statusText.text = "Busy mode on — I'll auto-reply to messages"
            speak("Busy mode on. I'll let people know you're busy until you turn this off.")
        } else {
            statusText.text = "Busy mode off"
            speak("Busy mode off.")
        }
    }
    private fun setBusyMessage(message: String) {
        prefs.edit().putString("busy_reply_message", message).apply()
        speak("Got it, I'll send that when busy mode is on.")
    }
    private fun setBusyCallMessage(message: String) {
        prefs.edit().putString("busy_call_message", message).apply()
        speak("Got it, I'll say that to callers when busy mode is on.")
    }

    private fun lookupPhoneNumber(name: String): String? {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS)
            != PackageManager.PERMISSION_GRANTED) return null

        val cursor = contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?",
            arrayOf("%$name%"),
            null
        )
        cursor?.use {
            if (it.moveToFirst()) {
                val numberIndex = it.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return it.getString(numberIndex).replace(" ", "").replace("-", "")
            }
        }
        return null
    }

    // Resolves either a raw number or a contact name to a number, preferring the number if digits are present
    private fun resolveTarget(spoken: String): String? {
        return if (spoken.any { it.isDigit() }) spoken else lookupPhoneNumber(spoken)
    }

    // ---- Open any installed app by its visible name, e.g. "open spotify", "open settings" ----
    private fun openAppByName(spokenName: String) {
        if (spokenName.isEmpty()) {
            speak("Which app should I open?")
            return
        }
        val pm = packageManager
        val mainIntent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val installedApps = pm.queryIntentActivities(mainIntent, 0)

        val match = installedApps.firstOrNull {
            it.loadLabel(pm).toString().lowercase().contains(spokenName.lowercase())
        }

        if (match == null) {
            speak("I couldn't find an app called $spokenName.")
            return
        }

        val launchIntent = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
        if (launchIntent != null) {
            speak("Opening ${match.loadLabel(pm)}.")
            startActivity(launchIntent)
        } else {
            speak("I found $spokenName but couldn't open it.")
        }
    }

    private fun openApp(packageName: String) {
        val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            Toast.makeText(this, "App not installed: $packageName", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openCamera() {
        val intent = Intent("android.media.action.IMAGE_CAPTURE")
        if (intent.resolveActivity(packageManager) != null) {
            startActivity(intent)
        }
    }

    private fun setFlashlight(on: Boolean) {
        try {
            val cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
            val cameraId = cameraManager.cameraIdList[0]
            cameraManager.setTorchMode(cameraId, on)
            flashlightOn = on
            statusText.text = if (on) "Flashlight on" else "Flashlight off"
        } catch (e: Exception) {
            statusText.text = "Couldn't control the flashlight on this device"
        }
    }

    private fun callContact(number: String) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number"))
        startActivity(intent)
    }

    private fun handleTextCommand(command: String) {
        // Expected pattern: "text <name or number> <message>"
        val rest = command.substringAfter("text ").trim()
        val parts = rest.split(" ", limit = 2)
        if (parts.size < 2) {
            statusText.text = "Say it like: \"text mom I'm on my way\""
            speak("Say it like: text, the name or number, then your message.")
            return
        }
        val number = resolveTarget(parts[0])
        val message = parts[1]
        if (number == null) {
            speak("I couldn't find a contact called ${parts[0]}.")
            return
        }
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(number, null, message, null, null)
            statusText.text = "Sent to $number"
            speak("Sent it.")
        } catch (e: Exception) {
            statusText.text = "Couldn't send the message"
            speak("Sorry, I couldn't send that message.")
        }
    }

    override fun onDestroy() {
        speechRecognizer.destroy()
        textToSpeech.stop()
        textToSpeech.shutdown()
        super.onDestroy()
    }
}
